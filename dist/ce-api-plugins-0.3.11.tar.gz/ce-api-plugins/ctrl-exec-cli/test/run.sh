#!/bin/bash
# Test suite for ctrl-exec-cli. Run: bash test/run.sh
# Runs the Perl unit tests under test/ with prove, then the run-jobs
# tests with bats.
set -u
DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "# Test report: ctrl-exec-cli (ce-api-plugins)"
echo "Generated: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
echo

out="$(cd "$DIR" && prove test/ 2>&1)"; rc=$?
echo "$out"
echo

if command -v bats > /dev/null 2>&1; then
    out="$(cd "$DIR" && bats test/run-jobs.bats test/heartbeat.bats 2>&1)" || rc=1
    echo "$out"
else
    echo "run-jobs: NOT RUN - bats is not installed"
    rc=1
fi
echo

[ "$rc" -eq 0 ] && echo "VERDICT: PASS" || echo "VERDICT: FAIL"
exit "$rc"
